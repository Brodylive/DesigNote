-- phpMyAdmin SQL Dump
-- version 3.3.7deb7
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Mer 11 Juin 2014 à 21:19
-- Version du serveur: 5.1.73
-- Version de PHP: 5.3.3-7+squeeze19

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `jenniferdenis`
--

-- --------------------------------------------------------

--
-- Structure de la table `notes`
--

CREATE TABLE IF NOT EXISTS `notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `img` varchar(100) DEFAULT NULL,
  `favoris` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Contenu de la table `notes`
--

INSERT INTO `notes` (`id`, `user_id`, `title`, `date`, `img`, `favoris`) VALUES
(1, 1, 'cest en essayant encore et encore que le singe apprend a bondir', '2014-02-12 14:30:00', 'img/note/1.jpg', 11),
(3, 1, 'Des démonistes insatiables détruisent une baleine.', '2014-03-18 15:18:37', 'img/note/2.jpg', 23),
(4, 1, 'Une randonneuse multicolore se révolte contre un orang-outang depuis un archipel.', '2014-03-18 15:19:00', 'img/note/3.jpg', 6),
(5, 1, 'Une muse sinistre joue aux petits chevaux dans un sauna.', '2014-03-19 15:19:24', 'img/note/4.jpg', 10),
(6, 1, 'Quand tout est fichu, il y a encore le courage.', '2014-03-20 16:19:42', 'img/note/5.jpg', 3),
(7, 1, 'La vie est une aventure audacieuse ou elle n est rien.', '2014-02-21 15:20:13', 'img/note/6.jpg', 10),
(8, 1, 'Il y a un éléphant rose dans mon caleçon.', '2014-02-24 15:20:45', 'img/note/7.jpg', 105),
(9, 1, 'Des voyants jettent des canards, il y a bien une chanson là-dessus.', '2014-02-26 15:21:29', 'img/note/8.jpg', 12),
(10, 1, 'Des poissons se moquent d un lièvre, schématiquement.', '2014-02-28 15:21:55', 'img/note/9.jpg', 76),
(11, 24, 'Il y a plus de courage que de talent dans la plupart des réussites.', '2014-03-02 15:22:26', 'img/note/10.jpg', 29);

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pseudo` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `img` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=29 ;

--
-- Contenu de la table `user`
--

INSERT INTO `user` (`id`, `pseudo`, `name`, `email`, `password`, `img`) VALUES
(27, 'Fkamey', 'Camille', 'camilleflorquin@gmail.com', '*C2D87828A3350AE884FA345C6CFE087BD0D5267C', 'img/user.jpg'),
(28, 'kamey', 'camille', 'camilleflorquin@gmail.com', '*C2D87828A3350AE884FA345C6CFE087BD0D5267C', 'img/user.jpg'),
(15, 'Pouette', 'Pouette', 'brodylive@gmail.com', '*CF6E1674E36B571CA309370F6613C85CFD8ABE08', 'img/user.jpg'),
(16, 'F_Kamey', 'Camille Florquin', 'camilleflorquin@gmail.com', '*A4B6157319038724E3560894F7F932C8886EBFCF', 'http://www.chaton0.com/chat-rigolo/chat-rigolo-2.jpg'),
(17, 'F_Kamey', 'Camille Florquin', 'camilleflorquin@gmail.com', '*A4B6157319038724E3560894F7F932C8886EBFCF', 'img/user.jpg'),
(19, 'bregovitch', 'brego', 'hh005@ydjdk.s', '*D825FE09D0C4815822DEC85AF7BE52A7D74653BC', 'img/user.jpg'),
(20, 'bla', 'bla', 'bla', '*C3169F309AF706040A4C882A85A5BADB40FBC744', 'http://www.1001-votes.com/vote/1234fonds/licorne-12.jpg'),
(21, 'L_beno', 'Londero Benoit', 'benolondero@gmail.com', '*56AF049F421F876FC51F8C610E3EBEB1284DC2C2', 'img/user.jpg'),
(22, 'Anne', 'Anne', 'Anne@anne.an', '*0B754DFA8CA00FCCE27929F308DE066197A24982', 'img/user.jpg'),
(23, 'blabla', 'kelly', 'kelly@gmail.com', '*E56A114692FE0DE073F9A1DD68A00EEB9703F3F1', 'http://www.wallfizz.com/animaux/chat/23-petit-chat-gris-WallFizz.jpg'),
(24, 'Ã¨hello', 'blublu', 'blublu', '*18CC7124BF684CA33F354ECE49F1D0D9346CBECF', 'img/user.jpg'),
(25, 'kamey', 'Camille', 'camilleflorquin@gmail.com', '*C2D87828A3350AE884FA345C6CFE087BD0D5267C', 'img/user.jpg'),
(26, 'Brodylive', 'Jennifer Denis', 'brodypattyns@gmail.com', '*CF6E1674E36B571CA309370F6613C85CFD8ABE08', 'img/user.jpg');
